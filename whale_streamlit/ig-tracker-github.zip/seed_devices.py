"""Pre-load the device -> IG account mapping. Idempotent: safe to re-run.

Edit DEVICE_MAP below and re-run `python seed_devices.py` to change the fleet.
Accounts that are active in the DB but no longer mapped to any device get
deactivated (their snapshot history is kept).
"""

from __future__ import annotations

import db

DEVICE_MAP = {
    "Claudia 1": "emmawavez",
    "Claudia 2": None,
    "Claudia 3": "sundaydarlingz",
    "Claudia 4": None,
    "Claudia 5": "littlemoonlanez",
    "Claudia 6": "dreamzemma",
    "Claudia 7": None,
    "Claudia 8": "coastemmavibes",
    "Claudia 9": "pinkvelvetdayz",
    "Claudia 10": "emma.coastt",
    "Claudia 11": "mysoftlifez",
    "Claudia 12": None,
    "Claudia 13": None,
    "Claudia 14": None,
    "Claudia 15": None,
    "Emma 1": "peachyweekend",
    "Emma 2": None,
    "Emma 3": "onlyyoungcutiee",
    "Emma 4": "meltemakimou",
    "Emma 5": "monadikhcutie",
    "Emma 6": "vanillaweekendz",
    "Emma 7": "mikrhomorfhthea",
    "Emma 8": None,
    "Emma 9": "cloudberryvibez",
    "Emma 10": "sweetgirllivingz",
}


def main() -> None:
    db.init_db()

    mapped_ids = set()
    for order, (device, username) in enumerate(DEVICE_MAP.items()):
        db.upsert_device(device, order)
        devices = {d["device_name"]: d for d in db.list_devices()}
        device_id = devices[device]["device_id"]
        if username:
            db.assign_device(device_id, username)
            mapped_ids.add(db.get_or_create_account(username))
        else:
            db.unassign_device(device_id)

    # deactivate any still-active account that isn't on a device anymore
    for acc in db.list_accounts(active_only=True):
        if acc["id"] not in mapped_ids:
            db.set_active(acc["id"], False)
            print(f"deactivated (not on any device): @{acc['username']}")

    filled = sum(1 for u in DEVICE_MAP.values() if u)
    print(f"seeded {len(DEVICE_MAP)} devices — {filled} linked, {len(DEVICE_MAP) - filled} empty slots")


if __name__ == "__main__":
    main()
