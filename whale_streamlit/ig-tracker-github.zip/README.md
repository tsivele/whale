# IG Tracker

Streamlit dashboard that tracks Instagram accounts via a third-party data API
(HikerAPI by default — the only one here that also covers stories; Apify and
EnsembleData as alternatives) and keeps a full history of metrics in SQLite.

HikerAPI cost: ~4 requests per account per cycle (profile, posts, reels,
stories). Stories only show while ACTIVE (24h), so the dashboard displays the
newest story timestamp ever recorded across snapshot history.

Per account: **followers**, **last reel views**, **last story time**, **last post time**.

## Quick start

```bash
cd ig-tracker
pip install -r requirements.txt
streamlit run streamlit_app.py
```

With no API token it runs on **mock data** so you can see the full flow
immediately. To go live with Apify:

1. `cp .env.example .env`
2. Apify Console (https://console.apify.com) → Settings → API & Integrations →
   copy your **Personal API token** → set `APIFY_TOKEN=...` in `.env`
3. Restart the app. Provider auto-selects apify when the token is present.

Apify uses two official actors per cycle (`instagram-profile-scraper` for
followers + last post, `instagram-reel-scraper` for reel views), batched
8 usernames per run. **Stories are not visible to Apify's official actors**
(login-walled), so the Last Story column stays "—" on this provider.

## How it works

- `streamlit_app.py` — Streamlit UI, one row per physical device (empty slots show
  "Ready to add"; link/unlink accounts from the sidebar). Only *reads* the DB,
  plus a "Fetch latest data" button (fetching is manual-only by design).
- `seed_devices.py` — pre-loads the device -> IG account fleet (Claudia 1-15,
  Emma 1-10). Edit `DEVICE_MAP` and re-run to change it; idempotent, and
  accounts removed from the map get deactivated (history kept).
- `report.py` — "Export Report" builds a ready-to-paste Telegram message
  (plain text + emoji): fleet summary, per-device metrics, and any account
  with an active issue flagged with 🚨. Issues (Link/Message restriction,
  Email verification, Banned, Other) are reported manually in the Issues
  section of the dashboard.
- `fetch_all.py` — one fetch cycle over all active accounts. Run it from cron
  every 30–60 min so the dashboard is always warm:
  `*/30 * * * * cd /path/to/ig-tracker && python3 fetch_all.py`
- `db.py` — SQLite schema + queries. Every fetch inserts a **snapshot** row,
  so follower history charts come for free.
- `fetchers/` — provider layer behind one interface (`Metrics` dataclass).
  `mock.py` needs nothing; `ensembledata.py` is the real one.

## Adapting to the provider's real response shapes

Scraping-API field names drift. If a metric shows `—` with a real token:

```bash
python fetch_all.py --debug natgeo
```

prints the raw provider JSON; then extend the alias lists in
`fetchers/ensembledata.py` (`first_key(...)` calls) or fix the endpoint path
constants at the top of that file. Stories in particular are not offered by
every provider/plan — the code tolerates a missing stories endpoint and logs
it under "Recent fetch errors" in the UI.

## Swapping providers (RapidAPI, Apify, …)

Add `fetchers/yourprovider.py` implementing `Fetcher.fetch(username) -> Metrics`,
then wire it into `fetchers/__init__.py:get_fetcher`. Nothing else changes.
