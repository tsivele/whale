"""One fetch cycle for all active accounts.

Usage:
    python fetch_all.py                    # fetch everything, save snapshots
    python fetch_all.py --debug USERNAME   # fetch one account, print raw JSON

Schedule it (the dashboard only reads the DB, so this can run from cron):
    */30 * * * * cd /path/to/ig-tracker && .venv/bin/python fetch_all.py
"""

from __future__ import annotations

import argparse
import sys

import db
from fetchers import Metrics, get_fetcher


def run(fetcher=None) -> dict:
    """Fetch all active accounts (batched where the provider supports it).

    Returns {'ok': int, 'failed': int, 'partial': int}.
    """
    db.init_db()
    fetcher = fetcher or get_fetcher()
    accounts = db.list_accounts(active_only=True)
    by_username = {a["username"].lower(): a for a in accounts}
    stats = {"ok": 0, "failed": 0, "partial": 0}

    try:
        results = fetcher.fetch_many(list(by_username))
    except Exception as e:  # noqa: BLE001 - whole cycle failed (auth, network, ...)
        db.log_error(None, fetcher.name, f"fetch cycle failed: {e}")
        stats["failed"] = len(by_username)
        return stats

    for username, acc in by_username.items():
        res = results.get(username)
        if res is None or isinstance(res, Exception):
            db.log_error(acc["id"], fetcher.name, str(res) if res else "no data returned")
            stats["failed"] += 1
            continue
        db.save_snapshot(acc["id"], res)
        if res.ig_user_id and not acc["ig_user_id"]:
            db.set_ig_user_id(acc["id"], res.ig_user_id)
        if res.partial_errors:
            db.log_error(acc["id"], fetcher.name, "; ".join(res.partial_errors))
            stats["partial"] += 1
        else:
            stats["ok"] += 1
    return stats


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--debug", metavar="USERNAME",
                    help="fetch one username and print the raw provider response")
    args = ap.parse_args()

    if args.debug:
        fetcher = get_fetcher(debug=True)
        m = fetcher.fetch(args.debug)
        assert isinstance(m, Metrics)
        print(f"\nprovider={fetcher.name}")
        print(f"followers={m.followers_count}  last_post={m.last_post_at}")
        print(f"reel_views={m.last_reel_views}  reel_at={m.last_reel_posted_at}")
        print(f"story_at={m.last_story_at}")
        for err in m.partial_errors:
            print(f"partial error: {err}")
        return 0

    stats = run()
    print(f"fetch cycle done: {stats}")
    return 1 if stats["failed"] and not (stats["ok"] or stats["partial"]) else 0


if __name__ == "__main__":
    sys.exit(main())
