"""IG Tracker — Streamlit dashboard, one row per physical device.

Reads SQLite; fetching is MANUAL ONLY (the button) so API credits are spent
only on demand. Seed/adjust the device fleet with seed_devices.py.
"""

from __future__ import annotations

from datetime import datetime, timezone

import pandas as pd
import streamlit as st

import db
import fetch_all
from fetchers import resolve_provider

st.set_page_config(page_title="IG Tracker", page_icon="📊", layout="wide")
db.init_db()


def rel_time(iso: str | None) -> str:
    """'2h ago' style rendering; '—' when unknown."""
    if not iso:
        return "—"
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return iso
    secs = (datetime.now(timezone.utc) - dt).total_seconds()
    if secs < 0:
        return "just now"
    for limit, unit in ((60, "s"), (3600, "m"), (86400, "h"), (86400 * 30, "d")):
        if secs < limit:
            prev = {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
            return f"{int(secs // prev)}{unit} ago"
    return dt.strftime("%Y-%m-%d")


@st.cache_data(ttl=120)
def hiker_requests_left():
    """Remaining prepaid HikerAPI requests, or None if unavailable."""
    import requests as rq

    from config import HIKER_BASE_URL, HIKER_TOKEN

    try:
        r = rq.get(f"{HIKER_BASE_URL}/sys/balance",
                   headers={"x-access-key": HIKER_TOKEN}, timeout=10)
        return r.json().get("requests")
    except Exception:  # noqa: BLE001 - balance display is best-effort
        return None


def fmt_num(n) -> str:
    if n is None:
        return "—"
    n = int(n)
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 10_000:
        return f"{n / 1_000:.1f}K"
    return f"{n:,}"


devices = db.list_devices()
if not devices:
    # fresh DB (e.g. first boot on Streamlit Cloud) — load the fleet automatically
    import seed_devices

    seed_devices.main()
    devices = db.list_devices()
linked = [d for d in devices if d["username"]]

# ---------------- Sidebar: device slots ----------------
with st.sidebar:
    st.header("📱 Devices")
    free = [d for d in devices if d["acc_id"] is None]
    if free:
        with st.form("assign", clear_on_submit=True):
            st.caption(f"{len(free)} empty slots")
            dev_name = st.selectbox("Device", [d["device_name"] for d in free])
            new_user = st.text_input("Instagram username", placeholder="e.g. emmawavez")
            if st.form_submit_button("Link account") and new_user.strip():
                dev = next(d for d in free if d["device_name"] == dev_name)
                db.assign_device(dev["device_id"], new_user)
                st.rerun()
    else:
        st.caption("All slots are full.")

    if linked:
        st.caption("Linked devices")
        for d in linked:
            col1, col2 = st.columns([4, 1])
            col1.write(f"**{d['device_name']}** · @{d['username']}")
            if col2.button("✕", key=f"un_{d['device_id']}",
                           help="Free this slot (account history is kept)"):
                db.unassign_device(d["device_id"])
                st.rerun()

    st.divider()
    provider = resolve_provider()
    st.caption(f"Data provider: **{provider}**")
    if provider == "mock":
        st.warning("No API token set — showing mock data. Copy .env.example to .env and add a token.")
    elif provider == "apify":
        st.caption("ℹ️ Apify can't see stories — the Last Story column stays “—”.")

# ---------------- Main: device table ----------------
st.title("📊 Instagram Tracker")

# Fetching is MANUAL ONLY (this button) — no scheduler, so API credits are
# spent only when the user decides.
est_cost = 4 * len(linked)
can_fetch = bool(linked)
if provider == "hikerapi" and linked:
    left = hiker_requests_left()
    if left is not None:
        st.caption(
            f"💳 HikerAPI: **{left:,} requests** left · κάθε fetch ≈ {est_cost} requests "
            f"→ χωράνε ακόμα **~{left // est_cost}** fetches"
        )
        if left < est_cost:
            st.error("Δεν φτάνουν τα requests για πλήρες fetch — κάνε top-up στο hikerapi.com")
            can_fetch = False

if st.button("🔄 Fetch latest data", type="primary", disabled=not can_fetch):
    with st.spinner("Fetching all linked accounts…"):
        stats = fetch_all.run()
    hiker_requests_left.clear()  # fresh balance on the next rerun
    msg = f"Done — ok: {stats['ok']}, partial: {stats['partial']}, failed: {stats['failed']}"
    (st.success if not stats["failed"] else st.warning)(msg)
    devices = db.list_devices()  # re-read so the table below shows fresh numbers

table = pd.DataFrame(
    [
        {
            "Device 📱": d["device_name"],
            "IG Account": (("🚨 " if d["active_issues"] else "") + f"@{d['username']}")
                          if d["username"] else "➕ Ready to add",
            "Followers 👥": fmt_num(d["followers_count"]) if d["username"] else "—",
            "Last Reel Views 📊": fmt_num(d["last_reel_views"]) if d["username"] else "—",
            "Last Story ⏱️": rel_time(d["last_story_seen"]) if d["username"] else "—",
            "Last Post 📅": rel_time(d["last_post_at"]) if d["username"] else "—",
            "Issues": d["active_issues"] or "—" if d["username"] else "—",
            "Updated": rel_time(d["fetched_at"]) if d["username"] else "—",
        }
        for d in devices
    ]
)
st.dataframe(table, width="stretch", hide_index=True, height=38 * len(devices) + 40)

# ---------------- Incident reporting ----------------
st.subheader("🚨 Issues")
col_form, col_list = st.columns([1, 1])

with col_form:
    if linked:
        with st.form("report_issue", clear_on_submit=True):
            st.markdown("**Report issue**")
            acc_options = {f"{d['device_name']} · @{d['username']}": d["acc_id"] for d in linked}
            target = st.selectbox("Account", list(acc_options))
            status = st.selectbox("Issue type", db.ISSUE_STATUSES)
            note = st.text_input("Note (optional)")
            if st.form_submit_button("Report 🚨"):
                db.report_issue(acc_options[target], status, note.strip())
                st.rerun()

with col_list:
    issues = db.active_issues()
    st.markdown(f"**Active issues ({len(issues)})**" if issues else "**No active issues** ✅")
    for i in issues:
        device = i["device_name"] or "(no device)"
        c1, c2 = st.columns([5, 1])
        c1.markdown(f"🚨 **{device}** · @{i['username']} — {i['status']}  \n"
                    f":gray[{rel_time(i['created_at'])}"
                    + (f" · {i['note']}" if i["note"] else "") + "]")
        if c2.button("✓", key=f"res_{i['id']}", help="Mark resolved"):
            db.resolve_issue(i["id"])
            st.rerun()

# ---------------- Telegram report ----------------
st.divider()
if st.button("📨 Export Report (Telegram message)"):
    import report

    st.caption("Πάτα το εικονίδιο αντιγραφής πάνω δεξιά και κάνε paste στο Telegram:")
    st.code(report.build_message(), language=None)

# ---------------- History chart ----------------
with_data = [d for d in linked if d["fetched_at"]]
if with_data:
    st.subheader("Followers over time")
    options = {f"{d['device_name']} · @{d['username']}": d["acc_id"] for d in with_data}
    chosen = st.selectbox("Device", list(options))
    hist = db.follower_history(options[chosen])
    if len(hist) >= 2:
        df = pd.DataFrame([dict(h) for h in hist])
        df["fetched_at"] = pd.to_datetime(df["fetched_at"])
        st.line_chart(df.set_index("fetched_at")["followers_count"])
    else:
        st.caption("Need at least two snapshots to draw a trend — fetch again later.")

# ---------------- Errors ----------------
errors = db.recent_errors(10)
if errors:
    with st.expander(f"⚠️ Recent fetch errors ({len(errors)})"):
        for e in errors:
            who = f"@{e['username']}" if e["username"] else "(general)"
            st.text(f"{e['occurred_at']}  {who}  [{e['source']}]  {e['message']}")
