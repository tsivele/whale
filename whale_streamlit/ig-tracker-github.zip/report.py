"""Fleet report as a ready-to-paste Telegram message (plain text + emoji)."""

from __future__ import annotations

from datetime import datetime, timezone

import db


def _rel(iso: str | None) -> str:
    if not iso:
        return "—"
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return iso
    secs = (datetime.now(timezone.utc) - dt).total_seconds()
    if secs < 3600:
        return f"{int(secs // 60)}m"
    if secs < 86400:
        return f"{int(secs // 3600)}h"
    if secs < 86400 * 30:
        return f"{int(secs // 86400)}d"
    return dt.strftime("%d/%m")


def _num(n) -> str:
    if n is None:
        return "—"
    n = int(n)
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 10_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def build_message() -> str:
    devices = db.list_devices()
    issues = db.active_issues()
    linked = [d for d in devices if d["username"]]

    lines = [
        f"📊 IG FLEET REPORT · {datetime.now().strftime('%d/%m %H:%M')}",
        f"👥 {len(linked)} accounts · 🚨 {len(issues)} issue(s)",
        "",
    ]

    if issues:
        lines.append("🚨 ISSUES:")
        for i in issues:
            device = i["device_name"] or "(no device)"
            note = f" — {i['note']}" if i["note"] else ""
            lines.append(f"• {device} @{i['username']}: {i['status']}"
                         f" ({_rel(i['created_at'])} ago){note}")
        lines.append("")

    # empty slots are noise in the report — only devices with an account
    for d in devices:
        if not d["username"]:
            continue
        mark = "🚨 " if d["active_issues"] else ""
        lines.append(f"{mark}{d['device_name']} @{d['username']}")
        lines.append(f"   👥 {_num(d['followers_count'])} · 🎬 {_num(d['last_reel_views'])}"
                     f" · ⏱ story {_rel(d['last_story_seen'])} · 📅 post {_rel(d['last_post_at'])}")

    return "\n".join(lines)


if __name__ == "__main__":
    print(build_message())
