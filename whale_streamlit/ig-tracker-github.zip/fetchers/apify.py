"""Apify provider (https://apify.com).

Uses two official actors via the synchronous run API
(`POST /v2/acts/{actor}/run-sync-get-dataset-items`):

- apify/instagram-profile-scraper  -> followers + latest posts (batched usernames)
- apify/instagram-reel-scraper     -> newest reels with play counts

Both actors accept many usernames per run, so a whole fetch cycle is a handful
of API calls instead of one per account (usernames are chunked to stay under
Apify's sync-run time limit).

LIMITATION: Apify's official actors cannot see STORIES (login-walled), so
last_story_at stays NULL with this provider.

Field names drift occasionally; parsing goes through first_key() aliases.
Debug a raw response with: python fetch_all.py --debug some_username
"""

from __future__ import annotations

import requests

from config import (
    APIFY_BASE_URL,
    APIFY_CHUNK_SIZE,
    APIFY_PROFILE_ACTOR,
    APIFY_REEL_ACTOR,
    APIFY_REELS_PER_USER,
    APIFY_TOKEN,
)

from .base import Fetcher, Metrics
from .parsing import first_key, to_iso


class ApifyError(RuntimeError):
    pass


def _chunks(items: list, size: int):
    for i in range(0, len(items), size):
        yield items[i : i + size]


class ApifyFetcher(Fetcher):
    name = "apify"
    supports_stories = False

    def __init__(self, debug: bool = False):
        if not APIFY_TOKEN:
            raise ApifyError("APIFY_TOKEN is not set (see .env.example)")
        self.debug = debug

    def _run_actor(self, actor: str, payload: dict) -> list:
        url = f"{APIFY_BASE_URL}/acts/{actor}/run-sync-get-dataset-items"
        resp = requests.post(url, params={"token": APIFY_TOKEN}, json=payload, timeout=330)
        if resp.status_code not in (200, 201):
            raise ApifyError(f"{actor} -> HTTP {resp.status_code}: {resp.text[:300]}")
        items = resp.json()
        if self.debug:
            import json
            print(f"--- {actor} ({len(items)} items) ---")
            print(json.dumps(items[:2], indent=2, ensure_ascii=False, default=str)[:6000])
        return items if isinstance(items, list) else []

    def fetch(self, username: str) -> Metrics:
        res = self.fetch_many([username])[username]
        if isinstance(res, Exception):
            raise res
        return res

    def fetch_many(self, usernames: list) -> dict:
        usernames = [u.lower() for u in usernames]
        out: dict = {u: Metrics(raw={}) for u in usernames}

        # ---- 1) Profiles: followers, user id, last post ----
        for chunk in _chunks(usernames, APIFY_CHUNK_SIZE):
            try:
                items = self._run_actor(APIFY_PROFILE_ACTOR, {"usernames": chunk})
            except Exception as e:  # noqa: BLE001 - whole chunk failed
                for u in chunk:
                    out[u] = ApifyError(f"profile run failed: {e}")
                continue
            seen = set()
            for item in items:
                u = (first_key(item, "username", "userName", "ownerUsername") or "").lower()
                if u not in out or isinstance(out[u], Exception):
                    continue
                seen.add(u)
                m = out[u]
                m.raw["profile"] = item
                m.followers_count = first_key(item, "followersCount", "followers_count", "followers")
                uid = first_key(item, "id", "pk", "userId")
                m.ig_user_id = str(uid) if uid is not None else None
                posts = item.get("latestPosts") or []
                ts = [to_iso(first_key(p, "timestamp", "taken_at", "taken_at_timestamp")) for p in posts]
                ts = [t for t in ts if t]
                if ts:
                    m.last_post_at = max(ts)
            for u in chunk:
                if u not in seen and not isinstance(out[u], Exception):
                    out[u] = ApifyError("profile not returned (private / renamed / banned?)")

        # ---- 2) Reels: newest reel + play count ----
        alive = [u for u in usernames if not isinstance(out[u], Exception)]
        for chunk in _chunks(alive, APIFY_CHUNK_SIZE):
            try:
                items = self._run_actor(
                    APIFY_REEL_ACTOR,
                    {"username": chunk, "resultsLimit": APIFY_REELS_PER_USER},
                )
            except Exception as e:  # noqa: BLE001 - reels are non-fatal
                for u in chunk:
                    out[u].partial_errors.append(f"reels: {e}")
                continue
            best: dict = {}
            for item in items:
                u = (first_key(item, "ownerUsername", "username", "userName") or "").lower()
                ts = to_iso(first_key(item, "timestamp", "taken_at", "taken_at_timestamp")) or ""
                if u in out and not isinstance(out[u], Exception):
                    if u not in best or ts > best[u][0]:
                        best[u] = (ts, item)
            for u, (ts, item) in best.items():
                m = out[u]
                m.raw["reel"] = item
                m.last_reel_views = first_key(
                    item, "videoPlayCount", "playCount", "videoViewCount", "viewCount"
                )
                m.last_reel_posted_at = ts or None
                m.last_reel_shortcode = first_key(item, "shortCode", "shortcode", "code")

        # Stories: not possible with official Apify actors (login-walled).
        # supports_stories=False lets the UI say so once instead of logging
        # an error per account per cycle.
        return out
