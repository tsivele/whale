"""HikerAPI provider (https://hikerapi.com) — covers ALL four metrics,
including stories (unlike Apify's official actors).

Auth: `x-access-key` header. Verified live 2026-07-19 against these endpoints:

- GET /v1/user/by/username?username=   -> profile: follower_count, pk
- GET /v1/user/medias?user_id=&amount= -> list of posts (taken_at ISO, code)
- GET /v1/user/clips?user_id=&amount=  -> list of reels (play_count, taken_at)
- GET /v1/user/stories/by/username     -> ACTIVE stories only (empty list = no
                                          story in the last 24h, not an error)

Items can be pinned out of order, so "last" = max(taken_at), not item[0].
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import requests

from config import HIKER_BASE_URL, HIKER_TOKEN

from .base import Fetcher, Metrics
from .parsing import first_key, to_iso

MEDIA_AMOUNT = 6      # posts/reels per account; a few, in case of pinned items
MAX_WORKERS = 4       # parallel accounts; well under HikerAPI's rate limit


class HikerError(RuntimeError):
    pass


class HikerFetcher(Fetcher):
    name = "hikerapi"
    supports_stories = True

    def __init__(self, debug: bool = False):
        if not HIKER_TOKEN:
            raise HikerError("HIKERAPI_TOKEN is not set (see .env.example)")
        self.debug = debug
        self.session = requests.Session()
        self.session.headers["x-access-key"] = HIKER_TOKEN

    def _get(self, path: str, **params):
        resp = self.session.get(f"{HIKER_BASE_URL}{path}", params=params, timeout=30)
        if resp.status_code != 200:
            raise HikerError(f"{path} -> HTTP {resp.status_code}: {resp.text[:200]}")
        return resp.json()

    @staticmethod
    def _newest(items: list) -> tuple:
        """(iso_timestamp, item) of the newest item by taken_at, or (None, None)."""
        best_ts, best = None, None
        for it in items or []:
            ts = to_iso(first_key(it, "taken_at", "taken_at_ts", "timestamp"))
            if ts and (best_ts is None or ts > best_ts):
                best_ts, best = ts, it
        return best_ts, best

    def fetch(self, username: str) -> Metrics:
        m = Metrics(raw={})

        info = self._get("/v1/user/by/username", username=username)
        m.raw["info"] = {k: info.get(k) for k in ("pk", "username", "follower_count",
                                                  "media_count", "is_private")}
        m.followers_count = info.get("follower_count")
        user_id = info.get("pk")
        if user_id is None:
            raise HikerError(f"no pk in profile response for @{username}")
        m.ig_user_id = str(user_id)
        if info.get("is_private"):
            m.partial_errors.append("account is private — media/stories not visible")
            return m

        try:
            posts = self._get("/v1/user/medias", user_id=user_id, amount=MEDIA_AMOUNT)
            m.last_post_at, _ = self._newest(posts)
        except Exception as e:  # noqa: BLE001 - partial data is still worth saving
            m.partial_errors.append(f"posts: {e}")

        try:
            clips = self._get("/v1/user/clips", user_id=user_id, amount=MEDIA_AMOUNT)
            ts, reel = self._newest(clips)
            if reel:
                m.last_reel_posted_at = ts
                m.last_reel_views = first_key(reel, "play_count", "view_count")
                m.last_reel_shortcode = reel.get("code")
        except Exception as e:  # noqa: BLE001
            m.partial_errors.append(f"reels: {e}")

        try:
            stories = self._get("/v1/user/stories/by/username", username=username)
            # empty list = no story live right now; the dashboard falls back to
            # the newest story timestamp ever recorded in snapshot history
            m.last_story_at, _ = self._newest(stories)
        except Exception as e:  # noqa: BLE001
            m.partial_errors.append(f"stories: {e}")

        if self.debug:
            import json
            print(json.dumps(m.raw, indent=2, ensure_ascii=False, default=str)[:4000])
        return m

    def fetch_many(self, usernames: list) -> dict:
        out: dict = {}

        def one(u):
            try:
                return u, self.fetch(u)
            except Exception as e:  # noqa: BLE001
                return u, e

        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
            for u, res in pool.map(one, usernames):
                out[u] = res
        return out
