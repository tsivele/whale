"""Fake data so the dashboard works end-to-end before any API token exists.

Numbers drift a little on every fetch so the history charts have movement.
"""

import hashlib
import random
import time
from datetime import datetime, timedelta, timezone

from .base import Fetcher, Metrics


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


class MockFetcher(Fetcher):
    name = "mock"

    def fetch(self, username: str) -> Metrics:
        seed = int(hashlib.md5(username.lower().encode()).hexdigest(), 16) % 10**6
        rng = random.Random(seed)
        base_followers = rng.randint(5_000, 900_000)
        # small per-fetch drift so charts aren't flat
        drift = random.Random(seed + int(time.time() // 300)).randint(-200, 400)
        now = datetime.now(timezone.utc)
        return Metrics(
            followers_count=base_followers + drift,
            last_post_at=_iso(now - timedelta(hours=rng.randint(1, 72))),
            last_story_at=_iso(now - timedelta(minutes=rng.randint(10, 60 * 20))),
            last_reel_views=rng.randint(1_000, 2_000_000),
            last_reel_posted_at=_iso(now - timedelta(hours=rng.randint(2, 120))),
            last_reel_shortcode="MOCK" + str(seed)[:6],
            ig_user_id=str(seed),
            raw={"provider": "mock"},
        )
