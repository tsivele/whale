from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union


@dataclass
class Metrics:
    """One fetch result for one account. Timestamps are ISO-8601 UTC strings."""

    followers_count: int | None = None
    last_post_at: str | None = None
    last_story_at: str | None = None
    last_reel_views: int | None = None
    last_reel_posted_at: str | None = None
    last_reel_shortcode: str | None = None
    ig_user_id: str | None = None
    raw: dict = field(default_factory=dict)
    # non-fatal problems for this account ("stories: endpoint 404", ...)
    partial_errors: list = field(default_factory=list)


class Fetcher:
    name = "base"
    supports_stories = True

    def fetch(self, username: str) -> Metrics:
        raise NotImplementedError

    def fetch_many(self, usernames: list) -> dict:
        """username -> Metrics (or the Exception that account failed with).

        Default is a per-account loop; batch-capable providers (Apify) override
        this to fetch many accounts in one API run.
        """
        out: dict[str, Union[Metrics, Exception]] = {}
        for u in usernames:
            try:
                out[u] = self.fetch(u)
            except Exception as e:  # noqa: BLE001 - callers decide how to log
                out[u] = e
        return out
