"""Small helpers for tolerating provider response-shape differences."""

from __future__ import annotations

from datetime import datetime, timezone


def first_key(d: dict | None, *keys):
    """Return the first non-None value among several possible field names."""
    if not isinstance(d, dict):
        return None
    for k in keys:
        v = d.get(k)
        if v is not None:
            return v
    return None


def to_iso(ts) -> str | None:
    """Accept unix seconds (int/str) or an ISO string; return ISO-8601 UTC."""
    if ts is None:
        return None
    if isinstance(ts, str):
        try:
            ts = float(ts)
        except ValueError:
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                return dt.astimezone(timezone.utc).isoformat(timespec="seconds")
            except ValueError:
                return None
    try:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc).isoformat(timespec="seconds")
    except (OverflowError, OSError, ValueError):
        return None
