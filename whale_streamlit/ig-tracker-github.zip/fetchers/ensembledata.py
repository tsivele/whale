"""EnsembleData provider (https://ensembledata.com).

Endpoint paths and response field names occasionally change and the public docs
are JS-rendered, so this file parses defensively: every field is looked up
under several known aliases, and each metric is fetched in its own try/except
so one broken endpoint doesn't kill the whole snapshot.

To see what the API really returns for your token, run:
    python fetch_all.py --debug some_username
and adjust the alias lists below if a field comes back None.
"""

from __future__ import annotations

import requests

from config import ED_BASE_URL, ED_TOKEN

from .base import Fetcher, Metrics
from .parsing import first_key, to_iso

USER_INFO_PATH = "/instagram/user/detailed-info"   # ?username=
USER_REELS_PATH = "/instagram/user/reels"          # ?user_id=&depth=1
USER_POSTS_PATH = "/instagram/user/posts"          # ?user_id=&depth=1
USER_STORIES_PATH = "/instagram/user/stories"      # ?user_id=  (availability varies)


class EnsembleDataError(RuntimeError):
    pass


class EnsembleDataFetcher(Fetcher):
    name = "ensembledata"

    def __init__(self, debug: bool = False):
        if not ED_TOKEN:
            raise EnsembleDataError("ED_TOKEN is not set (see .env.example)")
        self.debug = debug

    def _get(self, path: str, **params) -> dict:
        params["token"] = ED_TOKEN
        resp = requests.get(f"{ED_BASE_URL}{path}", params=params, timeout=30)
        if resp.status_code != 200:
            raise EnsembleDataError(f"{path} -> HTTP {resp.status_code}: {resp.text[:300]}")
        body = resp.json()
        return body.get("data", body)

    def fetch(self, username: str) -> Metrics:
        m = Metrics(raw={})

        # 1) Profile: followers + numeric user id (required by the other endpoints)
        info = self._get(USER_INFO_PATH, username=username)
        m.raw["info"] = info
        m.followers_count = first_key(info, "follower_count", "followers_count", "followers")
        user_id = first_key(info, "pk", "pk_id", "id", "user_id")
        if user_id is None:
            raise EnsembleDataError(f"could not find numeric user id in profile response for @{username}")
        m.ig_user_id = str(user_id)

        # 2) Last post timestamp
        try:
            posts = self._get(USER_POSTS_PATH, user_id=user_id, depth=1)
            m.raw["posts"] = posts
            post = self._newest_item(posts)
            if post:
                m.last_post_at = to_iso(first_key(post, "taken_at", "taken_at_timestamp", "timestamp"))
        except Exception as e:  # noqa: BLE001 - partial data is still worth saving
            m.partial_errors.append(f"posts: {e}")

        # 3) Last reel + its view count
        try:
            reels = self._get(USER_REELS_PATH, user_id=user_id, depth=1)
            m.raw["reels"] = reels
            reel = self._newest_item(reels)
            if reel:
                media = reel.get("media", reel)
                m.last_reel_views = first_key(media, "play_count", "ig_play_count", "view_count", "video_view_count")
                m.last_reel_posted_at = to_iso(first_key(media, "taken_at", "taken_at_timestamp", "timestamp"))
                m.last_reel_shortcode = first_key(media, "code", "shortcode")
        except Exception as e:  # noqa: BLE001
            m.partial_errors.append(f"reels: {e}")

        # 4) Last story timestamp (endpoint availability varies by plan/provider;
        #    if it 404s we just record the error and leave the field NULL)
        try:
            stories = self._get(USER_STORIES_PATH, user_id=user_id)
            m.raw["stories"] = stories
            story = self._newest_item(stories)
            if story:
                m.last_story_at = to_iso(first_key(story, "taken_at", "taken_at_timestamp", "timestamp"))
        except Exception as e:  # noqa: BLE001
            m.partial_errors.append(f"stories: {e}")

        if self.debug:
            import json
            print(json.dumps(m.raw, indent=2, ensure_ascii=False, default=str)[:8000])
        return m

    @staticmethod
    def _newest_item(payload) -> dict | None:
        """Providers wrap media lists differently; dig out the first item."""
        if payload is None:
            return None
        if isinstance(payload, list):
            return payload[0] if payload else None
        for key in ("posts", "reels", "items", "stories", "media", "data"):
            inner = payload.get(key)
            if isinstance(inner, list):
                return inner[0] if inner else None
            if isinstance(inner, dict):
                return EnsembleDataFetcher._newest_item(inner)
        return None
