from config import APIFY_TOKEN, ED_TOKEN, FETCH_PROVIDER, HIKER_TOKEN

from .base import Fetcher, Metrics  # noqa: F401
from .mock import MockFetcher


def resolve_provider() -> str:
    if FETCH_PROVIDER != "auto":
        return FETCH_PROVIDER
    if HIKER_TOKEN:
        return "hikerapi"
    if APIFY_TOKEN:
        return "apify"
    if ED_TOKEN:
        return "ensembledata"
    return "mock"


def get_fetcher(debug: bool = False) -> Fetcher:
    provider = resolve_provider()
    if provider == "hikerapi":
        from .hikerapi import HikerFetcher

        return HikerFetcher(debug=debug)
    if provider == "apify":
        from .apify import ApifyFetcher

        return ApifyFetcher(debug=debug)
    if provider == "ensembledata":
        from .ensembledata import EnsembleDataFetcher

        return EnsembleDataFetcher(debug=debug)
    return MockFetcher()
