"""SQLite layer: schema, snapshots history, and the queries the dashboard needs."""

from __future__ import annotations

import json
import sqlite3

from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id          INTEGER PRIMARY KEY,
    username    TEXT NOT NULL UNIQUE COLLATE NOCASE,
    ig_user_id  TEXT,
    is_active   INTEGER NOT NULL DEFAULT 1,
    added_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- One row per successful fetch: full metric history over time.
CREATE TABLE IF NOT EXISTS snapshots (
    id                   INTEGER PRIMARY KEY,
    account_id           INTEGER NOT NULL REFERENCES accounts(id),
    fetched_at           TEXT NOT NULL DEFAULT (datetime('now')),
    followers_count      INTEGER,
    last_post_at         TEXT,
    last_story_at        TEXT,
    last_reel_views      INTEGER,
    last_reel_posted_at  TEXT,
    last_reel_shortcode  TEXT,
    raw_json             TEXT
);
CREATE INDEX IF NOT EXISTS idx_snapshots_account_time
    ON snapshots(account_id, fetched_at DESC);

-- One physical device, optionally linked to the IG account that runs on it.
-- account_id NULL = empty slot ("Ready to add").
CREATE TABLE IF NOT EXISTS devices (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    account_id  INTEGER REFERENCES accounts(id)
);

-- Manually reported account problems. resolved_at NULL = still active.
CREATE TABLE IF NOT EXISTS issues (
    id               INTEGER PRIMARY KEY,
    account_id       INTEGER NOT NULL REFERENCES accounts(id),
    status           TEXT NOT NULL,
    note             TEXT,
    screenshot_path  TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    resolved_at      TEXT
);

CREATE TABLE IF NOT EXISTS fetch_errors (
    id          INTEGER PRIMARY KEY,
    account_id  INTEGER REFERENCES accounts(id),
    occurred_at TEXT NOT NULL DEFAULT (datetime('now')),
    source      TEXT,
    message     TEXT
);
"""


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(SCHEMA)


def add_account(username: str) -> bool:
    """Returns False if the username already exists."""
    username = username.strip().lstrip("@")
    if not username:
        return False
    with get_conn() as conn:
        try:
            conn.execute("INSERT INTO accounts (username) VALUES (?)", (username,))
            return True
        except sqlite3.IntegrityError:
            conn.execute("UPDATE accounts SET is_active = 1 WHERE username = ?", (username,))
            return False


def set_active(account_id: int, active: bool) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE accounts SET is_active = ? WHERE id = ?", (int(active), account_id))


def set_ig_user_id(account_id: int, ig_user_id: str) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE accounts SET ig_user_id = ? WHERE id = ?", (str(ig_user_id), account_id))


def list_accounts(active_only: bool = True) -> list[sqlite3.Row]:
    q = "SELECT * FROM accounts"
    if active_only:
        q += " WHERE is_active = 1"
    with get_conn() as conn:
        return conn.execute(q + " ORDER BY username").fetchall()


def save_snapshot(account_id: int, m) -> None:
    """m is a fetchers.base.Metrics instance."""
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO snapshots
               (account_id, followers_count, last_post_at, last_story_at,
                last_reel_views, last_reel_posted_at, last_reel_shortcode, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                account_id,
                m.followers_count,
                m.last_post_at,
                m.last_story_at,
                m.last_reel_views,
                m.last_reel_posted_at,
                m.last_reel_shortcode,
                json.dumps(m.raw, ensure_ascii=False, default=str),
            ),
        )


def log_error(account_id: int | None, source: str, message: str) -> None:
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO fetch_errors (account_id, source, message) VALUES (?, ?, ?)",
            (account_id, source, message[:2000]),
        )


ISSUE_STATUSES = [
    "Link restriction",
    "Message restriction",
    "Email verification required",
    "Banned",
    "Other restriction",
]


def report_issue(account_id: int, status: str, note: str | None = None,
                 screenshot_path: str | None = None) -> None:
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO issues (account_id, status, note, screenshot_path) VALUES (?, ?, ?, ?)",
            (account_id, status, note or None, screenshot_path),
        )


def resolve_issue(issue_id: int) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE issues SET resolved_at = datetime('now') WHERE id = ?", (issue_id,))


def active_issues() -> list[sqlite3.Row]:
    q = """
    SELECT i.*, a.username, d.name AS device_name
    FROM issues i
    JOIN accounts a ON a.id = i.account_id
    LEFT JOIN devices d ON d.account_id = a.id
    WHERE i.resolved_at IS NULL
    ORDER BY i.created_at DESC
    """
    with get_conn() as conn:
        return conn.execute(q).fetchall()


def upsert_device(name: str, sort_order: int) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO devices (name, sort_order) VALUES (?, ?)
               ON CONFLICT(name) DO UPDATE SET sort_order = excluded.sort_order""",
            (name, sort_order),
        )


def get_or_create_account(username: str) -> int:
    """Returns the account id, creating or re-activating as needed."""
    username = username.strip().lstrip("@").lower()
    with get_conn() as conn:
        row = conn.execute("SELECT id FROM accounts WHERE username = ?", (username,)).fetchone()
        if row:
            conn.execute("UPDATE accounts SET is_active = 1 WHERE id = ?", (row["id"],))
            return row["id"]
        return conn.execute("INSERT INTO accounts (username) VALUES (?)", (username,)).lastrowid


def assign_device(device_id: int, username: str) -> None:
    account_id = get_or_create_account(username)
    with get_conn() as conn:
        conn.execute("UPDATE devices SET account_id = ? WHERE id = ?", (account_id, device_id))


def unassign_device(device_id: int) -> None:
    """Frees the slot; the account is deactivated but its history is kept."""
    with get_conn() as conn:
        row = conn.execute("SELECT account_id FROM devices WHERE id = ?", (device_id,)).fetchone()
        if row and row["account_id"]:
            conn.execute("UPDATE accounts SET is_active = 0 WHERE id = ?", (row["account_id"],))
        conn.execute("UPDATE devices SET account_id = NULL WHERE id = ?", (device_id,))


def list_devices() -> list[sqlite3.Row]:
    """All devices in order, with account + latest snapshot (NULLs for empty slots)."""
    q = """
    SELECT d.id AS device_id, d.name AS device_name,
           a.id AS acc_id, a.username,
           s.followers_count, s.last_reel_views, s.last_post_at, s.fetched_at,
           (SELECT MAX(last_story_at) FROM snapshots WHERE account_id = a.id)
               AS last_story_seen,
           (SELECT GROUP_CONCAT(status, ' + ') FROM issues
            WHERE account_id = a.id AND resolved_at IS NULL) AS active_issues
    FROM devices d
    LEFT JOIN accounts a ON a.id = d.account_id
    LEFT JOIN snapshots s ON s.id = (
        SELECT id FROM snapshots
        WHERE account_id = a.id
        ORDER BY fetched_at DESC, id DESC LIMIT 1
    )
    ORDER BY d.sort_order, d.name
    """
    with get_conn() as conn:
        return conn.execute(q).fetchall()


def latest_snapshots() -> list[sqlite3.Row]:
    """Newest snapshot per active account, for the dashboard table."""
    q = """
    SELECT a.username, a.id AS account_id, s.*,
           -- stories expire after 24h and providers only see ACTIVE ones, so
           -- "last story" = newest story timestamp ever recorded, not just
           -- whatever the latest snapshot happened to catch
           (SELECT MAX(last_story_at) FROM snapshots WHERE account_id = a.id)
               AS last_story_seen
    FROM accounts a
    LEFT JOIN snapshots s ON s.id = (
        SELECT id FROM snapshots
        WHERE account_id = a.id
        ORDER BY fetched_at DESC, id DESC LIMIT 1
    )
    WHERE a.is_active = 1
    ORDER BY a.username
    """
    with get_conn() as conn:
        return conn.execute(q).fetchall()


def follower_history(account_id: int) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            """SELECT fetched_at, followers_count, last_reel_views
               FROM snapshots
               WHERE account_id = ? AND followers_count IS NOT NULL
               ORDER BY fetched_at""",
            (account_id,),
        ).fetchall()


def recent_errors(limit: int = 20) -> list[sqlite3.Row]:
    with get_conn() as conn:
        return conn.execute(
            """SELECT e.occurred_at, e.source, e.message, a.username
               FROM fetch_errors e LEFT JOIN accounts a ON a.id = e.account_id
               ORDER BY e.occurred_at DESC LIMIT ?""",
            (limit,),
        ).fetchall()
