import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

try:
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR / ".env")
except ImportError:  # .env loading is optional; plain env vars still work
    pass

DB_PATH = BASE_DIR / "tracker.db"

def _secret(name: str) -> str:
    """Streamlit Cloud provides secrets via st.secrets, not env vars."""
    try:
        import streamlit as st

        return str(st.secrets.get(name, "")).strip()
    except Exception:  # noqa: BLE001 - no secrets.toml / non-streamlit context
        return ""


ED_TOKEN = os.getenv("ED_TOKEN", "").strip()
ED_BASE_URL = os.getenv("ED_BASE_URL", "https://ensembledata.com/apis").rstrip("/")

HIKER_TOKEN = os.getenv("HIKERAPI_TOKEN", "").strip() or _secret("HIKERAPI_TOKEN")
HIKER_BASE_URL = os.getenv("HIKERAPI_BASE_URL", "https://api.hikerapi.com").rstrip("/")

APIFY_TOKEN = os.getenv("APIFY_TOKEN", "").strip()
APIFY_BASE_URL = os.getenv("APIFY_BASE_URL", "https://api.apify.com/v2").rstrip("/")
APIFY_PROFILE_ACTOR = os.getenv("APIFY_PROFILE_ACTOR", "apify~instagram-profile-scraper")
APIFY_REEL_ACTOR = os.getenv("APIFY_REEL_ACTOR", "apify~instagram-reel-scraper")
# usernames per actor run; keeps each sync call well under Apify's ~5 min limit
APIFY_CHUNK_SIZE = int(os.getenv("APIFY_CHUNK_SIZE", "8"))
# reels pulled per account (newest one wins; >1 tolerates pinned/out-of-order items)
APIFY_REELS_PER_USER = int(os.getenv("APIFY_REELS_PER_USER", "3"))

# auto | mock | hikerapi | apify | ensembledata
FETCH_PROVIDER = os.getenv("FETCH_PROVIDER", "auto").strip().lower()
